module Week42Exercise1 where
import Data.Either

{-
en funksjon: Either a b
(Either a b)
("hello", 32)
hello
32

-}
fromLeftAndRight :: (Either a b -> c) -> (a -> c, b -> c)
fromLeftAndRight f = 
    let l a = f (Left a)
        r b = f (Right b)
    in
        (l,r)

either' :: (a -> c) -> (b -> c) -> Either a b -> c
either' a b g = either a b g

toFstAndSnd :: (a -> (b, c)) -> (a -> b, a -> c)
toFstAndSnd f = 
    let
        a = fst . f
        b = snd . f
    in
        (a,b)

pair :: (a -> b) -> (a -> c) -> a -> (b, c)
pair f g x = (f x, g x)

