/**
 * Solution for 4.4.6
 * @author Eskil Yttri
 * @since 2022-03-09
 **/

package Pipl;

import java.util.ArrayList;
import java.util.List;

class ProcedureDeclaration {
    private final String name;
    private final List<Parameter> parameters;
    private final List<VarDecla> localVars;
    private final Stmt stmt;

    public ProcedureDeclaration(String name, List<Parameter> parameters, List<VarDecla> localVars, Stmt stmt, State state) {
        this.name = name;
        this.parameters = parameters;
        this.localVars = localVars;
        this.stmt = stmt;
    }

    public String getName() {
        return name;
    }

    public List<Parameter> getParameters() {
        return parameters;
    }

    public List<Var> getVarnames(List<Parameter> parameters) {
        List<Var> names = new ArrayList<>();
        for(int i = 0; i < parameters.size(); i++){
            VarDecla varDecla = parameters.get(i).getVarDecla();
            names.add(varDecla.getVar());
        }
        return names;
    }

    public List<VarDecla> getLocalVars() {
        return localVars;
    }

    public Stmt getStmt() {
        return stmt;
    }

    public static List<Value> eucliddiv_proc(int x, int y) {
        List<Parameter> parameters = new ArrayList<>();
        List<VarDecla> varDeclas = new ArrayList<>();

        parameters.add(new Parameter(Mode.OBS, new VarDecla(new Var("x"), Type.INTEGERTYPE)));
        parameters.add(new Parameter(Mode.OBS, new VarDecla(new Var("y"), Type.INTEGERTYPE)));
        parameters.add(new Parameter(Mode.OUT, new VarDecla(new Var("q"), Type.INTEGERTYPE)));
        parameters.add(new Parameter(Mode.OUT, new VarDecla(new Var("r"), Type.INTEGERTYPE)));


        State state = new State();
        List<Value> values = new ArrayList<>();
        values.add(new I(x));
        values.add(new I(y));


        ProcedureDeclaration eucliddiv = new ProcedureDeclaration("eucliddiv", parameters, varDeclas, Examples.eucliddiv_stmt, new State());
        List<Value> rts = allocate(parameters, values, Examples.eucliddiv_stmt);
        return rts;


    }

    public static List<Var> inputvars(List<Parameter> params){
        List<Var> vards = new ArrayList<>();
        for(int i = 0; i < params.size(); i++){
            Mode mode = params.get(i).getMode();
            if (mode == Mode.OBS) {
                VarDecla variable = params.get(i).getVarDecla();
                Var va = variable.getVar();
                vards.add(va);
            }
        }
        return vards;
    }

    public static List<Var> outputvars(List<Parameter> params){
        List<Var> vards = new ArrayList<>();
        for(int i = 0; i < params.size(); i++){
            Mode mode = params.get(i).getMode();
            if (mode == Mode.OUT) {
                VarDecla variable = params.get(i).getVarDecla();
                vards.add(variable.getVar());
            }
        }
        return vards;
    }

    // enviroment, store = allocatePandValue
    // locates variable names and insert their argument values into the store
    // env and store. 1. ( extract parameter names.) -> so x,y,q,r
    // so "x", x, new state. Parameters. the values. and a new store. ("x", new var x) and store.
    // empty env and store = allocate vartype -> (env, store) list of local variables in a store.
    // store'' = exec stmt with env store''

    // so add the variable names and their value to a list where we store them. the enviroment
    // is the location of each of them. new context means enviroment which is a string an location.
    // then another place take the local variables and add them to the list env. parameters.
    // then execute the stmt with the variables located in the local variable list.
    // then store = execute stmt with the

    // Step 1:
    // env, store = allocate param and value. so the name of x from input. the args and new context
    // this means: if we use add variable with value to the state. this means the name "x".
    // this means Parameter is the enviroment and state and we added "x" and it's value integer.
    // x is just a variable with an integer type.
    // so we just need to find the name. "X" in the parameter. and give x the value from our argument
    // this will be the value list. and we'll create an env, and store which is empty for this.
    // OK!

    //Step 2:
    // we now have another list with another env and store.
    // now we need to take the local variables and declarations and find them in the store.
    // so just add the variable to the store. so in step one we get the name from parameters
    // that match the name of the input. we then make the actual local variables connected to
    // the inputs. in a new list.

    // Step 3:
    // we now take the list from step 2. and execute the statement with the enviroment and store.

    // step 4:
    // we extract the values from the store. (extract the output variables.) from the first env and
    // the execution.



    public static List<Value> allocate(List<Parameter> params, List<Value> vals, Stmt stmt){
        var state = State.newState();
        List<Var> vars = inputvars(params);
        List<Value> returnvalues = new ArrayList<>();
        for(int i = 0; i < vars.size(); i++){
            for(int j = 0; j < vals.size(); j++){
                String name = vars.get(i).var;
                if(state.isVariable(name) == false){
                    state.addVariable(name, vals.get(i));
                }
            }
        }
        stmt.exec(state);
        List<Var> out = outputvars(params);
        for(int i = 0; i < out.size(); i++){
            String name = out.get(i).var;
            returnvalues.add(state.getValue(name));
        }

        return returnvalues;
    }


    public static void main(String[] args) {
        System.out.println(eucliddiv_proc(10, 3));
    }
}

class Parameter {
    private Mode mode;
    private VarDecla varDecla;

    public Parameter(Mode mode, VarDecla varDecla) {
        this.mode = mode;
        this.varDecla = varDecla;
    }

    public Mode getMode() {
        return mode;
    }

    public VarDecla getVarDecla() {
        return varDecla;
    }
}



class VarDecla {
    private Var var;
    private Type type;

    public VarDecla(Var var, Type type) {
        this.var = var;
        this.type = type;
    }

    public Var getVar() {
        return var;
    }

    public Type getType() {
        return type;
    }
}

enum Mode {
    OBS,
    UPD,
    OUT
}

enum Type {
    UNKNOWN,
    INTEGERTYPE,
    BOOLTYPE,
    LOCATIONTYPE
}

class Var {
    String var;

    public Var(String var) {
        this.var = var;
    }

    public String getVar() {
        return var;
    }

}