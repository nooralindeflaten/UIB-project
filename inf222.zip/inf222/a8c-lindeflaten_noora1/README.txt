
8.2.1:
    I just wanted to write a remark, because i almost didn't do anything in this task
    because it looked like you only wanted me to implement files to support the added
    unitname. 

    for instance, i thought about the fact that unitnames are strings so in interpreter
    i could have added a "getValue uname", but this didn't make sense to me because i didn't 
    have any use for this yet? a unitname is just a way to give a definition related to the expression
    and i found it unnecassary to do so right now. Sorry if this was the wrong interpretation of the task.

    i did think about creating a way to check the variable in the state linked to the value (for instance Lit i)
    and make it so that this var was assigned to the unit but again i'm unsure.

    5. I did try some examples from the assignment and it worked so i'm pretty happy it behaved as expected.

8.2.2
    Again, this works so i didn't spend more time digging deeper into it, but i must
    admitt i get confused by the documentation part with the docstrings and genarally the
    seperation of variables/types that carry theoretically the same elements.
    I did run the examples here and very happy when it works :)

8.2.3

    I was unsure if you wanted me to put in examples like (TLit i uname _) etc, so i didn't 
    but if this was the expected than just know that i did think about it :)

    The file has some bugs, i can't manage to get all of the types of the functions printed out
    when i run the setVar, so i think there is a bug between the unit/env and the function call
    this is where i get confused by the definitions. I did come to my own conclusion that the varEnv
    is just simply the variable name linked to the unit type (?) but i was unsure if i was to make this
    the same format as the unitenv (as in yarnUnits). So i just wrote down some things i thought made sense
    from looking at the pam8Signature test combined with the signature AST. 

    this is probably why i can't manage to get all of the types in the TStmt printed out.

    I thought it was best to just describe to you what i wanted to do in 3.
    I did want to simply check the stmt and expr like in Pam8USignatureAST and implement
    a way to output error strings like in the unittests, and like in realsemantics:
    realSemantics fname alist 
        = error $ "Unknown function name/arg list " ++ (show fname) ++ " " ++ (show alist)


    6. the problem is that unknown sources could override our program and cause it to behave
    in the wrong way, and not connecting the variables to the right environment. causing the unknownr
    sources to get to our information without caring about the right input. we can implement a static
    type system to enforce language separaion. Doing control checks without using extra run time. for
    instance like in the intrinsics. Only allowing a fixed number of arguments. 
