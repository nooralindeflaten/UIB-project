module IntrinsicsYarn0 where
import Pam8USignatureAST
import Pam8Signature
import Pam8UCalculatorTemplate

realSemantics :: FunModel Double
realSemantics "Add" [i1,i2] = i1 + i2
realSemantics "Mult" [i1,i2] = i1 * i2
realSemantics "Sub" [i1,i2] = i1 - i2
realSemantics "Neg" [i] = - i
realSemantics "Slash" [i1,0]
  = error $ "Cannot do real division (slash) of " ++ (show i1) ++ " by 0."
realSemantics "Slash" [i1,i2] = i1 / i2
realSemantics "Abs" [i] = abs i
realSemantics "Sqr" [i] = i * i
realSemantics "Pi" [] = pi
realSemantics "Sin" [i] = sin i
realSemantics "Cos" [i] = cos i
realSemantics "Exp" [i] = exp i
realSemantics "Ln" [i] = log i
realSemantics "Sqrt" [i] = sqrt i
realSemantics "Arctan" [i] = atan i
realSemantics "Idiv" [i1,0]
  = error $ "Cannot do integer division of " ++ (show i1) ++ " by 0."
realSemantics "Idiv" [i1,i2] = fromIntegral (truncate (i1 / i2))
realSemantics "Rem" [i1,0] 
  = error $ "Cannot do remainder of " ++ (show i1) ++ " by 0."
realSemantics "Rem" [i1,i2] = i1 - fromInteger (truncate (i1 / i2)) * i2
realSemantics "Succ" [i] = i + 1
realSemantics "Pred" [i] = i - 1
realSemantics fname alist 
  = error $ "Unknown function name/arg list " ++ (show fname) ++ " " ++ (show alist)



yarnUnits :: UnitEnvironment
yarnUnits =
    [("amount", "Amount"), ("NOK","Cost"),("gram/meter", "Density"),("g/m","Density"),
        ("meter","Length"), ("m","Length"),("NOK/meter","UnitCost"),("NOK/m","UnitCost"),
        ("gram","Weight"),("g","Weight")]

yarnOperations :: Signature
yarnOperations = 
    ([("Cost","thecost"),("Density","the dens"),("Weight", "the what"),("Length","theThing")],
    [("Add", ["Cost","Cost"],"Cost", "the calculation of cost"),
     ("Sub",["Cost","Cost"],"Cost", "The calculation of minus"),
     ("Mult", ["Density" , "Length"],"Weight", "what is dis"),
     ("Slash", ["Weight", "Density"], "Length", "pls save me"),
    ("Slash", ["Weight", "Length"], "Density", "slashing this"),
    ("Add", ["Length", "Length"], "Length", "slashing that"),
    ("Sub", ["Length", "Length"], "Length", "aub t"),
    ("Mult", ["Length", "Amount"], "Length", "did this"),
    ("Slash", ["Length", "Length"], "Amount", "hello h"),
    ("Mult", ["UnitCost", "Length"], "Cost", "gi gash"),
    ("Slash", ["Cost", "Length"], "UnitCost", "gg my guy"),
    ("Add", ["Weight", "Weight"], "Weight", "hey hottie"),
    ("Sub", ["Weight", "Weight"], "Weight", "lmao friends"),
    ("Mult", ["Weight", "Amount"], "Weight", "yo my dudes")])

yarnTestData :: [TypeName] -> [Double]
yarnTestData params = take (length params) [10..20]

{-
checkUnitModel :: Signature -> FunModel valuedomain -> TestData valuedomain -> [valuedomain]
checkFunModel (types,(fname,params,res,doc):fundecls) funmodel testfun
  = funmodel fname (testfun params)
    :checkFunModel (types,fundecls) funmodel testfun
checkFunModel (types,[]) funmodel testfun = []
-}
unittesttPam8IntrinsicsReal = do
  print $ "-- unittestPam8IntrinsicsReal --"
  -- print $ checkFunModel realOperations realSemantics realTestData
  print $
    -- Expected result of calling the declared functions on relevant argument lists.
    if (checkFunModel yarnOperations realSemantics yarnTestData) ==
        [21,110,-1,-10,10/11,10,100,pi,sin 10,cos 10,exp 10,log 10,sqrt 10,atan 10,0,10,11,9]
    then "Unit tests hold"
    else "Tests failed"


-----------------------
-- | Interactive calculator with variables an  d given selection of real operations.
main = do
  putStrLn $ "-- Scientific calculator for reals --"
  ucalculatorTemplate yarnOperations realSemantics yarnTestData