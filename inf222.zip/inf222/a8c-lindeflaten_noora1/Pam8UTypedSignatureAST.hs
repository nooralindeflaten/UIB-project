--hello
module Pam8UTypedSignatureAST where
import Pam8USignatureAST
import Pam8Signature

data TCalcExprAST valuedomain
    = TLit valuedomain UnitName TypeName
    | TFun FunName [TCalcExprAST valuedomain] TypeName
    | TVar VarName TypeName
    deriving (Eq, Read, Show)

data TCalcStmtAST valuedomain
   = TSetVar VarName (TCalcExprAST valuedomain)
   | TAssVar VarName (TCalcExprAST valuedomain)
   deriving (Eq, Read, Show)


getVariableType :: String -> TypeEnvironment -> TypeName
getVariableType vname tenv =
  case lookup vname tenv of
    Just typ -> typ
    Nothing ->  error $ "Variable " ++ vname ++ " not declared in " ++ (show tenv)


-- Infer a typed expression AST from an untyped AST, using
-- a signature, a unit environment and a variable environment.
-- If the type cannot be inferred, an empty string is used.
inferTypedExprAST :: Show valuedomain => Signature -> UnitEnvironment -> VarEnvironment -> CalcExprAST valuedomain -> TCalcExprAST valuedomain
inferTypedExprAST sig@(types,fundecls) uenv varenv (Lit i uname) = TLit i uname tname 
    where
        tname = 
            case lookup uname uenv of 
                Just tname -> tname
                Nothing -> ""

-- fun fn exprs. "prove typed expr"
{-
typeCheckExpr' :: [FunDeclaration] -> CalcExprAST valuedomain -> [FunName]
    typeCheckExpr' ((fname,params,res,doc):fundecls) fcall@(Fun fn exprs)
      = if fname == fn && length params == length exprs
        then undeclared exprs
        else typeCheckExpr' fundecls fcall
    typeCheckExpr' [] fcall@(Fun fn exprs) = fn:undeclared exprs
    -- | Check subexpressions
    undeclared exprs = foldr (++) [] (map (typeCheckExpr sig) exprs)

    sig ([typename,docstring],[funName,[typename],typename,docstring])

    we need to check the return type for the function name. then we need to check each subexpression
    and if the subexpression combined equals the required args for this function.
    so: if fn = "add" and exprs = [lit 4.0, mult [Lit 4.0, lit 4.0]] = 
-}

inferTypedExprAST sig@(types,((fname,args,ret,docs):fundecls)) unev varenv fcall@(Fun fn exprs) = TFun fn texps tname where
        texps = [inferTypedExprAST sig unev varenv (ex) | ex <- exprs]
        tp = [getType texp | texp <- texps]
        tname = if length args == length tp && fname == fn
            then ret
            else ""



        
inferTypedExprAST sig@(types,fundecls) ((uname,utype):unev) ((str,typ):varenv) (Var varname) = TVar varname vartype 
    where
        vartype = 
            case lookup varname varenv of
                Just typ -> typ
                Nothing -> ""



getType :: TCalcExprAST valuedomain -> TypeName
getType (TLit i unname tname) = tname
getType (TFun fn exprs tname) = tname
getType (TVar var tname) = tname

getexps :: CalcExprAST valuedomain -> Int
getexps (Fun fn exprs) = length exprs
-- Infer a typed statement AST from an untyped AST, using
-- a signature, a unit environment and a variable environment.
-- If the type cannot be inferred, an empty string is used.
inferTypedStmtAST :: Show valuedomain => Signature -> UnitEnvironment -> VarEnvironment -> CalcStmtAST valuedomain -> TCalcStmtAST valuedomain
inferTypedStmtAST sig@(types,fundecls) uenv varenv (SetVar vname exprs) = TSetVar vname texpr where
    texpr = inferTypedExprAST sig uenv varenv exprs
inferTypedStmtAST sig@(types,fundecls) uenv varenv (AssVar vname exprs) = TAssVar vname texpr where
    texpr = inferTypedExprAST sig uenv varenv exprs




-- | Checks whether each name in the list of type names is declared.
-- The type declarations are the first argument, the list of types the second.
-- Returns a list of all misspelled type names (from the second list).



-----------------------
-- | Checks that a function model provides a semantics for all functions declared in a signature.
-- Turns each function declaration in the signature into a call of the corresponding function,
-- in order to check the function model recognises a function and computes a result.
-- Uses a test data function which maps a parameter list to a corresponding list of values.




unittestPam8UTypedSignatureAST = do
    print $ "-- unittestPam8Signature --"
    let yarnUnits = [("amount", "Amount"), ("NOK","Cost"),("gram/meter", "Density"),("g/m","Density"),
                        ("meter","Length"), ("m","Length"),("NOK/meter","UnitCost"),("NOK/m","UnitCost"),
                        ("gram","Weight"),("g","Weight")]::UnitEnvironment

    let expr = Fun "Mult" [(Lit 0.35 "NOK/meter"), Fun "Slash"[Fun "Mult" [
                (Lit 160.0 "gram"), (Lit 4.0 "amount")], (Lit 0.2 "gram/meter")]]

    let exprs = [(Lit 0.35 "NOK/meter"), Fun "Slash"[Fun "Mult" [
                (Lit 160.0 "gram"), (Lit 4.0 "amount")], (Lit 0.2 "gram/meter")]]
            
    let sig1 = ([("Cost",""),("Density",""),("Weight", ""),("Length",""),("Amount", "")],
                [("Slash", ["Weight", "Density"], "Length", ""),
                 ("Mult", ["UnitCost", "Length"], "Cost", ""),
                 ("Mult", ["Weight", "Amount"], "Weight", "")])::Signature
    let fmode "Add" [i1,i2] = i1 + i2
    let fmode "Mult" [i1,i2] = i1 * i2
    let fmode "Slash" [i1,i2] = i1 / i2
    let vars = [("a","Amount"), ("cost","Cost"),("density","Density"),
                    ("len","Length"),("uc","UnitCost"),
                        ("w","Weight")]::VarEnvironment
    let texps = [inferTypedExprAST sig1 yarnUnits vars (ex) | ex <- exprs]
    let tp = [getType texp | texp <- texps]
    --let v = inferTypedExprAST sig1 yarnUnits vars (Fun "Mult" [(Lit 0.35 "NOK/meter"), Fun "Slash"[Fun "Mult" [
      --          (Lit 160.0 "gram"), (Lit 4.0 "amount")], (Lit 0.2 "gram/meter")]])
    let ch = inferTypedExprAST sig1 yarnUnits vars expr
    let h = getType ch
    print $ ch
    print $ tp
    

