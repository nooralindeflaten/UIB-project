module Pam8USignatureAST where

import Pam8Signature


data CalcExprAST valuedomain
    = Lit valuedomain UnitName
    | Fun FunName [CalcExprAST valuedomain]
    | Var VarName
    deriving (Eq, Read, Show)
-- | Statement for declaring (setting) and changing (assigning) a variable
data CalcStmtAST valuedomain
  = SetVar VarName (CalcExprAST valuedomain)
  | AssVar VarName (CalcExprAST valuedomain)
  deriving (Eq, Read, Show)

-----------------------
-- | Check that an expression is compatible with a given signature.
-- Returns a list of undeclared functions used in the expression.

{-
- each Unit name should only have one type. Lit = valueDomain. 
- A unit should be a unique type and only declared once. 
- we need to check that the string of the unitname is only declared once.
- mapping it in the valueDomain.

Signature = [typeDecl],[funDecls]
    FunDeclaration = (FunName,[TypeName],TypeName, DocString)
    TypeDeclaration = (TypeName,DocString)
    FunModel valuedomain = FunName -> [valuedomain] -> valuedomain
    type State valuedomain = (Environment,Store valuedomain)
    type Store valuedomain = Array Integer valuedomain

-- | Checks that the type environment is a mapping from strings to types.
-- Generally, a type environment is an association list from strings to type names,
-- and may contain multiple types for each string.
-- A mapping gives each string a unique type. 
-- Thus we need to check that each string appears only once in the environment.
checkUniqueMap :: TypeEnvironment -> [String]
checkUniqueMap ((str,typ):utm) = case lookup str utm of
  Nothing -> checkUniqueMap utm
  Just typ' -> str:checkUniqueMap utm
checkUniqueMap [] = []

we need to check that the unitName is corresponding with the signature.
So the Lit valuedomain is just a literal variable with the unit name. 

we find the unitname in the literal valuedomain. let's say this is Lit 5 unitname.
this needs to be compatible with the given types and fundecls. 
so a literal variable used in the signature 

#get varType lit i uName in varTypes. 

find argument types of uName in ftypes. then checkExpr sigs i. 
-}

typeCheckExpr :: Signature -> CalcExprAST valuedomain -> [FunName]
typeCheckExpr sig@(types,fundecls) (Lit _ uName) = [] 

{-    
    foldr (++) [] (map (typeCheckExpr sig uName))
    Nothing -> typeCheckExpr i
    just typ' -> uName:checkExpr i
-}
typeCheckExpr sig@(types,fundecls) fcall@(Fun fn exprs) = typeCheckExpr' fundecls fcall
  where
    typeCheckExpr' :: [FunDeclaration] -> CalcExprAST valuedomain -> [FunName]
    typeCheckExpr' ((fname,params,res,doc):fundecls) fcall@(Fun fn exprs)
      = if fname == fn && length params == length exprs
        then undeclared exprs
        else typeCheckExpr' fundecls fcall
    typeCheckExpr' [] fcall@(Fun fn exprs) = fn:undeclared exprs
    -- | Check subexpressions
    undeclared exprs = foldr (++) [] (map (typeCheckExpr sig) exprs)
typeCheckExpr sig@(types,fundecls) (Var _) = []

unittestPam8SignatureAST = do
  print $ "-- unittestPam8SignatureAST --"
  let sig1 = ([("Int","")],[("Neg",["Int"],"Int","")])::Signature
  let sig2 = ([("Int","")],[("Neg",["Int"],"Int",""),("Add",["Int"],"Int","")])::Signature
  let sig3 = ([("Int","")],[("Neg",["Int"],"Int",""),("Add",["Int","int"],"Int","")])::Signature
  let sig4 = ([("Int","")],[("Neg",["Int"],"Int",""),("Add",["Int","int"],"Int",""),("Mult",["Int","int"],"Int",""),("Sub",["Int","int"],"Int","")])::Signature
  let expr = Fun "Neg" [Fun "Mult" [Fun "Add" [(Lit 3 "n"),(Fun "Sub" [(Lit 7 "x"),(Lit 13 "y")])],(Lit 19 "z")]]
  let ch1 = typeCheckExpr sig1 expr == ["Mult","Add","Sub"]
  let ch2 = typeCheckExpr sig2 expr == ["Mult","Add","Sub"]
  let ch3 = typeCheckExpr sig3 expr == ["Mult","Sub"]
  let ch4 = typeCheckExpr sig4 expr == []
  print $ if ch1 && ch2 && ch3 && ch4 then "OK" else "Not OK"